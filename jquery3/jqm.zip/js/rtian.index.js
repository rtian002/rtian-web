var path = window.location.pathname.substring(1);
	path = path.substring(path.lastIndexOf("/")+1);
if (path != "jquery3.html")	{
	window.location.href="jquery3.html#" + path;
}

		var $main_menu=$('aside .grid-item'),
		$sub_menus=$('aside .grid .grid-item > ul'),
		$sub_menu=$('aside .grid .grid-item > ul ul li'),
		$sub_menu2=$('article .grid .grid-item > ul ul li');

$('.content a[href^="#"]').click(function(){
	var q=$(this).attr("href").substring(1);
	if (q == "index.html" )
	{		
		$sub_menus.slideUp("fast"), 
		$main_menu.removeClass("active"),
		$sub_menu.removeClass();
		$('article .content').hide(),
		$('article #index').show();

	}else{
		var $b=$sub_menu.find('a[href="#' + q + '"]').parent();
		var a=$b.parentsUntil('.grid-item').parent();
		$sub_menu.removeClass(),
		$b.addClass('active');
		if (a.hasClass('active') == false)
		{
			$sub_menus.slideUp("fast"), 
			$main_menu.removeClass("active"),
			a.find('ul').slideDown(),
			a.addClass("active");
			}

		$('article #index').hide(),
		$('article .content').show();
		$('article .content').load(q);
	}
});
